import "./PageOne.css"
function PageOne() {
    return (
      <div className="pageOne">
        <h1>Page One11</h1>
        <p>This is the content of Page One.</p>
      
      </div>
  );
};

export default PageOne;