import React, { useState } from 'react';
import PageOne from './PageOne/PageOne';
import PageTwo from './PageTwo/PageTwo';
import PageThree from './PageThree/PageThree';
import MemberDetailModal from './Member/Member';


function App() {
  
  const [selectedMember, setSelectedMember] = useState(null);

  const members = [
    { id: 1, name: 'Alice', role: 'President', bio: 'Alice is the president of the club.' },
    { id: 2, name: 'Bob', role: 'Vice President', bio: 'Bob is the vice president and loves chess.' },
    { id: 3, name: 'Charlie', role: 'Secretary', bio: 'Charlie is the secretary and enjoys hiking.' }
  ];

  return (
    
    <div>
      <nav>
      <ul>
        <li><a href="">member</a></li>
        <li><a href="">video</a></li>
        <li><a href="#PageTwo">about us</a></li>
        <li><a href="#PageOne">home</a></li>
      </ul>
    </nav>
      <PageOne />
      <PageTwo />
      <PageThree />
      <h2>Members List</h2>
      <ul>
        {members.map((member) => (
          <li key={member.id}>
            <span>{member.name} - {member.role}</span>
            <button onClick={() => setSelectedMember(member)}>View Details</button>
          </li>
        ))}
      </ul>

      {/* 멤버 상세 정보 모달 */}
      <MemberDetailModal
        member={selectedMember}
        onClose={() => setSelectedMember(null)}
      />
    </div>
  );
};

export default App;