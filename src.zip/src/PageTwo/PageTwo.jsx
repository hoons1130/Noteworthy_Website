import "./PageTwo.css"
import VideoSlider from "./Button";

function PageTwo() {

  const videos = [
    'QHqUXFsKwZQ',
    'cDjY-1WuB3o',
    'oNoCPGvcCdI',
    '7cUgZIO7iKY',
    '7zQGp12hsMU',
    'ZCLVgKUWtyI'
  ];


    return (
      <div className="pageTwo">
        <h1>Page Two</h1>
        <p>This is the content of Page Two.</p>
        <VideoSlider videos={videos} />
      </div>

  );
};

export default PageTwo;