import React, { useState } from 'react';
import "./PageTwo.css"

function VideoSlider({ videos }) {
  // 현재 영상의 인덱스를 추적하는 상태
  const [currentIndex, setCurrentIndex] = useState(0);

  // 이전 영상으로 이동
  const goToPrevious = () => {
    const newIndex = currentIndex > 0 ? currentIndex - 1 : videos.length - 1;
    setCurrentIndex(newIndex);
  };

  // 다음 영상으로 이동
  const goToNext = () => {
    const newIndex = currentIndex < videos.length - 1 ? currentIndex + 1 : 0;
    setCurrentIndex(newIndex);
  };

  return (
    <div>
        <div >
            <button className="slideBar1" onClick={goToPrevious}>Previous</button>
        </div>
        <div className="video-responsive">
            <iframe
            src={`https://www.youtube.com/embed/${videos[currentIndex]}`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="Embedded youtube"
            />
        </div>
        <div>
            <button className="slideBar2" onClick={goToNext}>Next</button>
        </div>
    </div>
  );
};

export default VideoSlider;
