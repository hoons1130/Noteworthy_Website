import "./PageThree.css"
function PageThree() {
    return (
      <div className="pageThree">
        <h1>Page Three</h1>
        <p>This is the content of Page Three.</p>
      </div>
  );
};

export default PageThree;